
const express = require('express');
const jwt = require('jsonwebtoken');
const bodyParser = require('body-parser');
const app = express();
const port = 4000;

app.use(bodyParser.json());

const SECRET_KEY = 'supersecretkey';

// Mock users and tokens
const users = [
  { id: 1, username: 'user1', password: 'pass1', tokens: 3 },
  { id: 2, username: 'user2', password: 'pass2', tokens: 0 }
];

function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.sendStatus(401);

  jwt.verify(token, SECRET_KEY, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
}

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username && u.password === password);
  if (!user) return res.status(401).json({ message: 'Invalid credentials' });

  const token = jwt.sign({ username: user.username, id: user.id }, SECRET_KEY, { expiresIn: '1h' });
  res.json({ token });
});

app.get('/access', authenticateToken, (req, res) => {
  const user = users.find(u => u.username === req.user.username);
  if (!user) return res.status(404).json({ message: 'User not found' });

  if (user.tokens > 0) {
    user.tokens -= 1;
    res.json({ message: 'Access granted', remainingTokens: user.tokens });
  } else {
    res.status(403).json({ message: 'No tokens left' });
  }
});

app.listen(port, () => {
  console.log(`Token access system running on port ${port}`);
});
