
# Token Access System

This is a simple backend Express.js app demonstrating:

- User login with JWT authentication
- Token-based access control system
- Simple mock database with tokens decrement on access

## Run Instructions

1. Install dependencies:
```
npm install
```
2. Start the server:
```
npm start
```
3. API Endpoints:
- POST /login {username, password} - to get JWT token
- GET /access (with Bearer token) - to check and consume a token
